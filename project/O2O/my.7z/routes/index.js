/*
其中a,b,c为用户的用户名，pwd_u为密码
role标识是用户还是商家，1代表商家，2代表用户；tel为用户电话。
d,e,f为商家的用户名，pwd_s为密码，service为商家提供的服务。
*/ 
var data = require("fs").readFileSync("users.json","utf-8");
var users = JSON.parse(data);

module.exports = function(app) {
    app.get('/', function(req, res) {
        res.render('login');
    });
    app.get('/list', function(req, res) {
        res.render('list');
    });
    app.get('/shops', function(req, res) {
        res.render('shops');
    });
    app.post('/login', function(req, res) {
        var name = req.body.name;
        var user = users[name];
        if (user && user.pwd_s == req.body.pwd && "1" == req.body.role) {
            console.log('商家登录~');
            res.cookie('name_s', name);
            res.cookie('role', req.body.role);
            res.redirect('/shops'); //转到商家页面
        } else if (user && user.pwd_u == req.body.pwd && "2" == req.body.role) {
            console.log('用户登录~');
            res.cookie('name_u', name);
            res.cookie('role', req.body.role);
            res.cookie('tel',user.tel);
            console.log(user.tel);
            res.redirect('/list'); //转到用户页面
        } else {
            res.sendStatus(404);
        }
    });
};
